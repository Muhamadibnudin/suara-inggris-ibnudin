1. Upload index.html + config.js ke repository GitHub Pages.
2. Jalankan Colab sampai PUBLIC URL muncul.
3. Edit config.js:
   const API_URL = "https://URL-NGROK-ANDA.ngrok-free.app";
4. Commit.
5. Aktifkan GitHub Pages di Settings > Pages.
6. Colab dan tunnel ngrok harus tetap hidup.

Jangan upload NGROK_AUTHTOKEN ke GitHub.
