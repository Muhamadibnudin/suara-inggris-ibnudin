// Ganti dengan URL NGROK yang muncul di Colab.
const API_URL = "PASTE_NGROK_URL_HERE";
