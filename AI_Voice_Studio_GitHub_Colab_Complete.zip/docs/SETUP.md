# Setup

## Colab
Open `colab/AI_Voice_Studio_Complete.ipynb`, select T4 GPU, then run all cells in order.

## GitHub
Create a GitHub Pages repository and upload the contents of `github-pages/` to the repository root:
- index.html
- style.css
- app.js
- config.js
- .nojekyll

## config.js
After Colab prints:
`https://xxxxx.ngrok-free.app`

change:
`const API_URL = "PASTE_NGROK_URL_HERE";`

to:
`const API_URL = "https://xxxxx.ngrok-free.app";`

Do not publish your ngrok authtoken.

## Pages
Repository → Settings → Pages → Deploy from a branch → main → root → Save.

Keep Colab running while the website needs the API.
