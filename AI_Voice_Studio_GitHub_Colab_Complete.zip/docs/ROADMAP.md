# Roadmap

1. Voice cloning: OpenVoice V2 + reference voice.
2. American English: MeloTTS `EN-US` base speaker.
3. Long text: automatic chunking and WAV merging. The browser has no small character limit; the API caps a single request at 1,000,000 characters to protect the runtime.
4. Character/emotion: natural, happy, excited, sad, calm, serious, angry, whisper presets.
5. Automatic SFX: keyword/scene detection and locally generated procedural effects (rain, thunder, wind, footsteps, door/knock, phone/ring, engine, impact, alarm, magic, whoosh).
6. Download: generated WAV is served by the API and linked from the page.
7. GitHub Pages: static frontend only.
8. ngrok: temporary public bridge to the Colab API.

Future upgrade: replace procedural SFX with a local royalty-free SFX library for more cinematic results.
