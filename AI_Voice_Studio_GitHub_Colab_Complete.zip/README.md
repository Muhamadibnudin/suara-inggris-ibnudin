# AI Voice Studio — GitHub Pages + Colab

Repo-ready project for:
- long text TTS (chunked automatically)
- cloning your own reference voice
- American English base speaker
- emotion/speed presets
- automatic scene SFX without an external SFX API
- WAV playback/download
- GitHub Pages frontend
- FastAPI + ngrok backend

## Architecture
GitHub Pages → ngrok → Google Colab T4 → FastAPI → MeloTTS EN-US → OpenVoice V2 → WAV/SFX.

## Start
1. Open `colab/AI_Voice_Studio_Complete.ipynb` in Google Colab.
2. Select T4 GPU.
3. Run cells from top to bottom.
4. Upload your reference voice.
5. Test the generated voice.
6. Let the notebook start FastAPI and ngrok.
7. Copy the printed PUBLIC URL.
8. Upload the five files in `github-pages/` to the root of a GitHub Pages repo.
9. Paste the PUBLIC URL into `github-pages/config.js`.
10. Enable GitHub Pages.

Only clone voices you own or have permission to use.
