import os,re,uuid,wave,math,struct,threading,subprocess
from pathlib import Path
import torch
from fastapi import FastAPI,HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
from openvoice.api import ToneColorConverter
from melo.api import TTS

DEVICE="cuda" if torch.cuda.is_available() else "cpu"
ROOT=Path("/content/voice_studio"); OUT=ROOT/"outputs"; OUT.mkdir(parents=True,exist_ok=True)
CKPT=Path("/content/OpenVoice/checkpoints_v2")
REFERENCE=ROOT/"reference_voice.wav"; TARGET=ROOT/"target_se.pth"
if not REFERENCE.exists() or not TARGET.exists(): raise RuntimeError("Reference voice setup is incomplete.")

converter=ToneColorConverter(str(CKPT/"converter/config.json"),device=DEVICE,enable_watermark=False)
converter.load_ckpt(str(CKPT/"converter/checkpoint.pth"))
melo=TTS(language="EN",device=DEVICE); speakers=melo.hps.data.spk2id
source_se=torch.load(str(CKPT/"base_speakers/ses/en-us.pth"),map_location=DEVICE)
target_se=torch.load(str(TARGET),map_location=DEVICE)

app=FastAPI(title="AI Voice Studio API")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_credentials=False,allow_methods=["*"],allow_headers=["*"])
LOCK=threading.Lock()

class Req(BaseModel):
    text:str
    emotion:str="natural"
    speed:float=1.0
    sfx:str="auto"

def chunks(text,n=650):
    text=re.sub(r"\s+"," ",text).strip()
    if not text:return []
    ss=re.split(r"(?<=[.!?])\s+",text); out=[]; cur=""
    for s in ss:
        if len(s)>n:
            for w in s.split():
                if len(cur)+len(w)+1<=n:cur=(cur+" "+w).strip()
                else:
                    if cur:out.append(cur)
                    cur=w
        elif len(cur)+len(s)+1<=n:cur=(cur+" "+s).strip()
        else:
            if cur:out.append(cur)
            cur=s
    if cur:out.append(cur)
    return out

def spd(e,s):
    p={"natural":1,"happy":1.04,"excited":1.10,"sad":.88,"calm":.90,"serious":.94,"angry":1.08,"whisper":.82}
    return max(.7,min(1.3,float(s)*p.get(e.lower(),1)))

def sfx_detect(t,e):
    t=t.lower(); groups={
    "thunder":["thunder","storm","lightning"],"rain":["rain","raining","rainy"],
    "wind":["wind","windy"],"knock":["door","knock","knocking"],"ring":["phone","telephone","ring"],
    "footsteps":["footstep","footsteps","walking"],"engine":["car","engine","driving"],
    "impact":["explosion","explode","blast"],"alarm":["alarm","siren"],
    "magic":["magic","spell"],"whoosh":["whoosh","swoosh"]}
    r=[name for name,ks in groups.items() if any(k in t for k in ks)]
    if e.lower()=="excited":r.append("whoosh")
    return list(dict.fromkeys(r))

def tone(path,kind,d=.6,sr=44100):
    n=int(sr*d); freq={"thunder":70,"rain":5000,"wind":260,"knock":120,"ring":900,"footsteps":95,"engine":80,"impact":55,"alarm":1000,"magic":650,"whoosh":320}.get(kind,440)
    b=bytearray()
    for i in range(n):
        x=i/sr; env=min(1,i/(.04*sr))*min(1,(n-i)/(.12*sr))
        if kind=="rain":v=(2*torch.rand(1).item()-1)*.18
        elif kind=="wind":v=math.sin(2*math.pi*freq*x)*.16+math.sin(2*math.pi*70*x)*.08
        elif kind=="whoosh":v=math.sin(2*math.pi*(freq+900*x/d)*x)*(x/d)*.18
        elif kind=="impact":v=math.sin(2*math.pi*freq*x)*math.exp(-8*x)*.6
        else:v=math.sin(2*math.pi*freq*x)*env*.22
        b+=struct.pack("<h",int(max(-1,min(1,v))*32767))
    with wave.open(str(path),"wb") as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes(b)

def merge(ps,out):
    with wave.open(str(ps[0]),"rb") as f:p=f.getparams()
    with wave.open(str(out),"wb") as d:
        d.setparams(p)
        for x in ps:
            with wave.open(str(x),"rb") as s:d.writeframes(s.readframes(s.getnframes()))

@app.get("/health")
def health():return {"ok":True,"gpu":torch.cuda.is_available(),"device":DEVICE}

@app.post("/generate")
def generate(q:Req):
    t=q.text.strip()
    if not t:raise HTTPException(400,"Text is empty.")
    if len(t)>1000000:raise HTTPException(400,"Maximum 1,000,000 characters per request.")
    cs=chunks(t); job=uuid.uuid4().hex; jd=OUT/job;jd.mkdir()
    with LOCK:
        parts=[]; rate=spd(q.emotion,q.speed)
        for i,c in enumerate(cs):
            a=jd/f"src{i}.wav";b=jd/f"v{i}.wav"
            melo.tts_to_file(c,speakers["EN-US"],str(a),speed=rate)
            converter.convert(audio_src_path=str(a),src_se=source_se,tgt_se=target_se,output_path=str(b),message="@MyShell")
            parts.append(b)
        voice=jd/"voice.wav";merge(parts,voice)
        events=[] if q.sfx=="off" else sfx_detect(t,q.emotion)
        if events:
            mixed=jd/"final.wav";cmd=["ffmpeg","-y","-i",str(voice)]
            for i,k in enumerate(events):p=jd/f"sfx{i}.wav";tone(p,k);cmd+=["-i",str(p)]
            fs=["[0:a]aresample=44100[base]"];cur="[base]"
            for i,k in enumerate(events,1):
                lab=f"s{i}";fs.append(f"[{i}:a]adelay={5000*(i-1)+1000}:all=1[{lab}]")
                nxt=f"[m{i}]";fs.append(f"{cur}[{lab}]amix=inputs=2:duration=first:normalize=0{nxt}");cur=nxt
            cmd+=["-filter_complex",";".join(fs),"-map",cur,"-c:a","pcm_s16le",str(mixed)]
            subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            if mixed.exists():voice=mixed
    return {"ok":True,"job_id":job,"chunks":len(cs),"sfx_events":len(events),"audio_url":f"/audio/{job}"}

@app.get("/audio/{job}")
def audio(job):
    p=OUT/job/"final.wav"
    if not p.exists():p=OUT/job/"voice.wav"
    if not p.exists():raise HTTPException(404,"Audio not found.")
    return FileResponse(str(p),media_type="audio/wav",filename="ai-voice-studio.wav")
