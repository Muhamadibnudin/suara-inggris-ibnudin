# AI Voice Studio — GitHub Pages

Upload `index.html`, `style.css`, `app.js`, `config.js`, and `.nojekyll` to the ROOT of your GitHub Pages repository.

After Colab prints an address such as `https://abc123.ngrok-free.app`, edit `config.js`:

```js
const API_URL = "https://abc123.ngrok-free.app";
```

GitHub Pages is only the frontend. Python/TTS runs in Google Colab.
