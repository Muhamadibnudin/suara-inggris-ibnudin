const textEl=document.getElementById("text"),counter=document.getElementById("counter"),emotionEl=document.getElementById("emotion"),speedEl=document.getElementById("speed"),sfxEl=document.getElementById("sfx"),btn=document.getElementById("generate"),status=document.getElementById("status"),player=document.getElementById("player"),download=document.getElementById("download");
textEl.oninput=()=>counter.textContent=`${textEl.value.length.toLocaleString()} characters`;
btn.onclick=async()=>{
 const text=textEl.value.trim();
 if(!text){status.textContent="Please enter text.";return}
 if(!API_URL.startsWith("https://")||API_URL.includes("PASTE_NGROK")){status.textContent="Set API_URL in config.js first.";return}
 btn.disabled=true;status.textContent="Generating...";download.style.display="none";
 try{
  const r=await fetch(API_URL+"/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text,emotion:emotionEl.value,speed:Number(speedEl.value),sfx:sfxEl.value})});
  const d=await r.json();if(!r.ok)throw Error(d.detail||"Generation failed");
  const u=API_URL+d.audio_url;player.src=u;player.load();download.href=u;download.style.display="inline-block";
  status.textContent=`Done • ${d.chunks} speech chunks • ${d.sfx_events} SFX events`;
 }catch(e){status.textContent="Error: "+e.message}finally{btn.disabled=false}
};